﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDiseaseInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.grdDisease = New UJGrid.UJGrid()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnSet = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnInput = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.txtDisplay)
        Me.Panel1.Controls.Add(Me.grdDisease)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(931, 498)
        Me.Panel1.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnCreate)
        Me.Panel3.Controls.Add(Me.btnDisplay)
        Me.Panel3.Controls.Add(Me.btnSave)
        Me.Panel3.Location = New System.Drawing.Point(12, 245)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(259, 235)
        Me.Panel3.TabIndex = 7
        '
        'btnCreate
        '
        Me.btnCreate.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCreate.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnCreate.Location = New System.Drawing.Point(38, 20)
        Me.btnCreate.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(173, 38)
        Me.btnCreate.TabIndex = 4
        Me.btnCreate.Text = "Create File"
        Me.btnCreate.UseVisualStyleBackColor = False
        '
        'btnDisplay
        '
        Me.btnDisplay.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDisplay.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnDisplay.Location = New System.Drawing.Point(38, 140)
        Me.btnDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(173, 37)
        Me.btnDisplay.TabIndex = 6
        Me.btnDisplay.Text = "Read from File"
        Me.btnDisplay.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSave.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSave.Location = New System.Drawing.Point(38, 81)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(173, 37)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "Write to File"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'txtDisplay
        '
        Me.txtDisplay.Location = New System.Drawing.Point(280, 245)
        Me.txtDisplay.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(597, 235)
        Me.txtDisplay.TabIndex = 2
        '
        'grdDisease
        '
        Me.grdDisease.FixedCols = 1
        Me.grdDisease.FixedRows = 1
        Me.grdDisease.Location = New System.Drawing.Point(280, 12)
        Me.grdDisease.Name = "grdDisease"
        Me.grdDisease.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdDisease.Size = New System.Drawing.Size(596, 214)
        Me.grdDisease.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.btnSet)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.btnInput)
        Me.Panel2.Location = New System.Drawing.Point(12, 12)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(259, 214)
        Me.Panel2.TabIndex = 0
        '
        'btnSet
        '
        Me.btnSet.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnSet.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSet.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSet.Location = New System.Drawing.Point(37, 12)
        Me.btnSet.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSet.Name = "btnSet"
        Me.btnSet.Size = New System.Drawing.Size(173, 39)
        Me.btnSet.TabIndex = 1
        Me.btnSet.Text = "Set"
        Me.btnSet.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button2.Location = New System.Drawing.Point(37, 137)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(173, 37)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Display"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'btnInput
        '
        Me.btnInput.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnInput.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnInput.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInput.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnInput.Location = New System.Drawing.Point(37, 76)
        Me.btnInput.Name = "btnInput"
        Me.btnInput.Size = New System.Drawing.Size(173, 39)
        Me.btnInput.TabIndex = 2
        Me.btnInput.Text = "Input Information"
        Me.btnInput.UseVisualStyleBackColor = False
        '
        'frmDiseaseInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 494)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmDiseaseInfo"
        Me.Text = "Disease Information Collection"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents btnInput As Button
    Friend WithEvents btnSet As Button
    Friend WithEvents grdDisease As UJGrid.UJGrid
    Friend WithEvents btnCreate As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents btnDisplay As Button
    Friend WithEvents Panel3 As Panel
End Class
