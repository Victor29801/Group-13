﻿' *****************************************************************
' Team Number: 13
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Hans, S (220097353)
' Team Member 3 Details: Victor, A (220000845)
' Team Member 4 Details: Lutchman, KS (219014915)
' Practical: Team Project
' Class name: Deficiency
' *****************************************************************

Option Explicit On
Option Strict On
Option Infer Off
<Serializable()> Public Class Deficiency
    Inherits Diseases

    Public Sub New(name As String, NumCountries As Integer)
        MyBase.New(name, NumCountries)
        _Type = "Deficiency"
    End Sub
    Public Overrides Function AverageCasesForDisease() As Double
        Return MyBase.AverageCasesForDisease()
    End Function

    Public Overrides Function TotalDeathToll() As Integer
        Return MyBase.TotalDeathToll()
    End Function

    Public Overrides Function HighestCases() As Integer
        Return MyBase.HighestCases()
    End Function


    Public Overrides Function Display() As String
        Return MyBase.Display()
    End Function
End Class
