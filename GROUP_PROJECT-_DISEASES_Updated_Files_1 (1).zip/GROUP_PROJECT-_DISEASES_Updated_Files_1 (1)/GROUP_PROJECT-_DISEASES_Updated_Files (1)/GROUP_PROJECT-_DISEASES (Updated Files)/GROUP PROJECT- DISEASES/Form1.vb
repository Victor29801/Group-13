﻿' *****************************************************************
' Team Number: 13
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Hans, S (220097353)
' Team Member 3 Details: Victor, A (220000845)
' Team Member 4 Details: Lutchman, KS (219014915)
' Practical: Team Project
' Class name: Infectious
' *****************************************************************
Option Explicit On
Option Infer Off
Option Strict On

Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class frmDiseaseInfo
    Private ObjDiseases() As Diseases
    Private NumDiseases, NumCountries As Integer
    Private objPhysiological As Physiological
    Private objInfectious As Infectious
    Private objhereditary As Hereditary
    Private objDefieciency As Deficiency

    Private FS As FileStream
    Private BF As BinaryFormatter
    Private Const FileName As String = "Disease Information.txt"

    Enum DiseaseType
        Deficiency = 1
        infectious
        hereditary
        Physiological
    End Enum

    Private Sub btnSet_Click(sender As Object, e As EventArgs) Handles btnSet.Click
        'Sets the number of diseases
        NumDiseases = CInt(InputBox("Enter the number of Diseases:"))
        ReDim ObjDiseases(NumDiseases)

        'Sets the number of countries
        NumCountries = CInt(InputBox("Enter the number of Countries:"))

        'Set grid dimensions 
        grdDisease.Rows = NumDiseases + 1
        grdDisease.Cols = 6
        LabelGrid()

    End Sub

    Private Sub btnStore_Click(sender As Object, e As EventArgs) Handles btnInput.Click
        For s As Integer = 1 To NumDiseases
            Dim Diseases As Integer = CInt(InputBox("Please select the type of Disease : " &
                                        Environment.NewLine & "1-Deficiency:" &
                                        Environment.NewLine & "2-infectious :" &
                                        Environment.NewLine & "3-hereditary :" &
                                        Environment.NewLine & "4-Physiological :", "Disease Type Entry"))

            Dim DiseaseID As String = InputBox("Disease Name:", "Disease Name Entry")
            PT(s, 0, DiseaseID)

            Select Case Diseases
                Case DiseaseType.Deficiency
                    PT(s, 1, "Deficiency")
                    objDefieciency = New Deficiency(DiseaseID, NumCountries)
                    For m As Integer = 1 To NumCountries
                        objDefieciency.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?", "Cases Entry"))
                        objDefieciency.DeathToll(m) = CInt(InputBox("How many deaths for country " & CStr(m)))
                    Next m
                    Dim value As String = InputBox("Is the Disease Contagious, Y for yes, N for No")
                    If value = "Y" Then
                        objDefieciency.Contagious = True
                    Else
                        If value = "N" Then
                            objDefieciency.Contagious = False
                        End If
                    End If
                    PT(s, 2, CStr(objDefieciency.Contagious))

                    ObjDiseases(s) = objDefieciency

                Case DiseaseType.infectious
                    PT(s, 1, "infectious")
                    objInfectious = New Infectious(DiseaseID, NumCountries)
                    For m As Integer = 1 To NumCountries
                        objInfectious.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?"))
                        objInfectious.DeathToll(m) = CInt(InputBox("how many deaths for country " & CStr(m)))
                    Next m
                    Dim value As String = InputBox("Is the Disease Contagious, Y for yes, N for No")
                    If value = "Y" Then
                        objInfectious.Contagious = True
                    Else
                        If value = "N" Then
                            objInfectious.Contagious = False
                        End If
                    End If
                    PT(s, 2, CStr(objInfectious.Contagious))

                    ObjDiseases(s) = objInfectious

                Case DiseaseType.hereditary
                    PT(s, 1, "hereditary")
                    objhereditary = New Hereditary(DiseaseID, NumCountries)
                    For m As Integer = 1 To NumCountries
                        objhereditary.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?"))
                        objhereditary.DeathToll(m) = CInt(InputBox("how many deaths for country " & CStr(m)))
                    Next m
                    Dim value As String = InputBox("Is the Disease Contagious, Y for yes, N for No")
                    If value = "Y" Then
                        objhereditary.Contagious = True
                    Else
                        If value = "N" Then
                            objhereditary.Contagious = False
                        End If
                    End If
                    PT(s, 2, CStr(objhereditary.Contagious))

                    ObjDiseases(s) = objhereditary

                Case DiseaseType.Physiological
                    PT(s, 1, "Physiological")
                    objPhysiological = New Physiological(DiseaseID, NumCountries)
                    For m As Integer = 1 To NumCountries
                        objPhysiological.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?"))
                        objPhysiological.DeathToll(m) = CInt(InputBox("how many deaths for country " & CStr(m)))
                    Next m
                    Dim value As String = InputBox("Is the Disease Contagious, Y for yes, N for No")
                    If value = "Y" Then
                        objPhysiological.Contagious = True
                    Else
                        If value = "N" Then
                            objPhysiological.Contagious = False
                        End If
                    End If
                    PT(s, 2, CStr(objPhysiological.Contagious))

                    ObjDiseases(s) = objPhysiological
            End Select
        Next s
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim TotalDeaths, HighestCase As Integer
        Dim AvgCases As Double

        For s As Integer = 1 To NumDiseases
            'Deficiency: 
            Dim tempObjDefieciency As Deficiency
            tempObjDefieciency = TryCast(ObjDiseases(s), Deficiency)
            If Not (tempObjDefieciency Is Nothing) Then
                HighestCase = tempObjDefieciency.HighestCases()
                AvgCases = tempObjDefieciency.AverageCasesForDisease()
                TotalDeaths = tempObjDefieciency.TotalDeathToll()
            End If

            'Infectious
            Dim tempObjInfectious As Infectious
            tempObjInfectious = TryCast(ObjDiseases(s), Infectious)
            If Not (tempObjInfectious Is Nothing) Then
                HighestCase = tempObjInfectious.HighestCases()
                AvgCases = tempObjInfectious.AverageCasesForDisease()
                TotalDeaths = tempObjInfectious.TotalDeathToll()
            End If

            'Hereditary
            Dim tempObjhereditary As Hereditary
            tempObjhereditary = TryCast(ObjDiseases(s), Hereditary)
            If Not (tempObjhereditary Is Nothing) Then
                HighestCase = tempObjhereditary.HighestCases()
                AvgCases = tempObjhereditary.AverageCasesForDisease()
                TotalDeaths = tempObjhereditary.TotalDeathToll()
            End If

            'Physiological
            Dim tempObjPhysiological As Physiological
            tempObjPhysiological = TryCast(ObjDiseases(s), Physiological)
            If Not (tempObjPhysiological Is Nothing) Then
                HighestCase = tempObjPhysiological.HighestCases()
                AvgCases = tempObjPhysiological.AverageCasesForDisease()
                TotalDeaths = tempObjPhysiological.TotalDeathToll()
            End If

            PT(s, 3, Format(AvgCases, "0.00"))
            PT(s, 4, CStr(TotalDeaths))
            PT(s, 5, "Country:" & HighestCase)
        Next
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        FS = New FileStream(FileName, FileMode.Create, FileAccess.ReadWrite)
        MsgBox("File Created!")
        FS.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Write to file
        FS = New FileStream(FileName, FileMode.Open, FileAccess.Write)
        BF = New BinaryFormatter()
        For s As Integer = 1 To NumDiseases

            BF.Serialize(FS, ObjDiseases(s))
        Next
        FS.Close()
        MsgBox("Saved!")
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        'Displaying Data
        txtDisplay.Clear()

        'Setting filestreams
        FS = New FileStream(FileName, FileMode.Open, FileAccess.Read)
        BF = New BinaryFormatter()

        'Deserialising data
        While FS.Position < FS.Length
            Dim tempDisease As Object
            tempDisease = BF.Deserialize(FS)

            If TypeOf tempDisease Is Infectious Then
                Dim temp As Infectious
                temp = DirectCast(tempDisease, Infectious)
                txtDisplay.Text &= temp.Display
            End If
            If TypeOf tempDisease Is Hereditary Then
                Dim temp As Hereditary
                temp = DirectCast(tempDisease, Hereditary)
                txtDisplay.Text &= temp.Display
            End If

            If TypeOf tempDisease Is Deficiency Then
                Dim temp As Deficiency
                temp = DirectCast(tempDisease, Deficiency)
                txtDisplay.Text &= temp.Display
            End If

            If TypeOf tempDisease Is Physiological Then
                Dim temp As Physiological
                temp = DirectCast(tempDisease, Physiological)
                txtDisplay.Text &= temp.Display
            End If
        End While

        FS.Close()
    End Sub

    Private Sub PT(r As Integer, c As Integer, t As String)
        'Places Text in the grid 
        grdDisease.Row = r
        grdDisease.Col = c
        grdDisease.Text = t
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub frmDiseaseInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LabelGrid()
        'Labels the Grid 
        For a As Integer = 1 To NumDiseases
            PT(a, 0, "Disease: " & CStr(a))
        Next

        PT(0, 0, "Disease Name")
        PT(0, 1, "Type")
        PT(0, 2, "Contagious")
        PT(0, 3, "Average Cases")
        PT(0, 4, "Total Deaths")
        PT(0, 5, "Country Most Deaths")
    End Sub

End Class
