﻿' *****************************************************************
' Team Number: 13
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Hans, S (220097353)
' Team Member 3 Details: Victor, A (220000845)
' Team Member 4 Details: Lutchman, KS (219014915)
' Practical: Team Project
' Class name: Diseases
' *****************************************************************

Option Explicit On
Option Strict On
Option Infer Off

'Abstract Class
<Serializable()> Public MustInherit Class Diseases
    'Attributes
    Private _Name As String
    Private _CasesPerCountry() As Integer
    Private _NumCountries As Integer
    Private _DeathToll() As Integer
    Protected _Type As String = "Disease"

    'Constructor
    Public Sub New(Name As String, NumCountries As Integer)
        _Name = Name
        _NumCountries = NumCountries
        ReDim _CasesPerCountry(_NumCountries)
        ReDim _DeathToll(_NumCountries)
    End Sub

    'Property Methods: Accessors and Mutators
    Public Property Type As String
        Get
            Return _Type
        End Get
        Set(value As String)
            _Type = value
        End Set
    End Property

    Public Property Countries(index As Integer) As Integer
        Get
            Return _CasesPerCountry(index)
        End Get
        Set(value As Integer)
            _CasesPerCountry(index) = value
        End Set
    End Property

    Public Property DeathToll(index As Integer) As Integer
        Get
            Return _DeathToll(index)
        End Get
        Set(value As Integer)
            _DeathToll(index) = value
        End Set
    End Property

    'Other Functions 
    'Calculates and returns the average cases per disease
    Public Overridable Function AverageCasesForDisease() As Double
        Dim average As Double
        average = TotalHelper(_CasesPerCountry) / (_CasesPerCountry.Length - 1)
        Return average
    End Function

    'Calculates and returns the total death toll 
    Public Overridable Function TotalDeathToll() As Integer
        Return TotalHelper(_DeathToll)
    End Function

    'Calculates and returns the index of the country with the highest case 
    Public Overridable Function HighestCases() As Integer
        Dim maxIndex As Integer = 1
        Dim max As Integer = _CasesPerCountry(1)

        For s As Integer = 2 To _NumCountries
            If max < _CasesPerCountry(s) Then
                max = _CasesPerCountry(s)
                maxIndex = s
            End If
        Next s
        Return maxIndex
    End Function

    'Display Function
    Public Overridable Function Display() As String
        Return "Disease Name: " & _Name & " / Type: " & _Type & " / Average Cases: " & Format(AverageCasesForDisease(), "0.00") & " / Total Deaths : " & CStr(TotalDeathToll()) & "/ Highest Case: Country " & CStr(HighestCases())
    End Function

    'Calculates and returns the total
    Private Function TotalHelper(ByRef Array() As Integer) As Integer
        Dim total As Integer
        For s As Integer = 1 To (Array.Length - 1)
            total += Array(s)
        Next s
        Return total
    End Function
End Class
