﻿' *****************************************************************
' Team Number: 13
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Hans, S (220097353)
' Team Member 3 Details: Victor, A (220000845)
' Team Member 4 Details: Lutchman, KS (219014915)
' Practical: Team Project
' Class name: Deficiency
' *****************************************************************

Option Explicit On
Option Strict On
Option Infer Off
<Serializable()> Public Class Deficiency
    Inherits Diseases

    'Attributes
    Private _Catagory As Integer

    'Constructor
    Public Sub New(name As String, NumCountries As Integer, Catagory As Integer)
        MyBase.New(name, NumCountries)
        _Type = "Deficiency"
        _Catagory = Catagory
    End Sub

    'Methods
    Public Overrides Function AverageCasesForDisease() As Double
        Return MyBase.AverageCasesForDisease()
    End Function

    Public Overrides Function TotalDeathToll() As Integer
        Return MyBase.TotalDeathToll()
    End Function

    Public Overrides Function HighestCases() As Integer
        Return MyBase.HighestCases()
    End Function

    Public Overrides Function Display() As String
        Return MyBase.Display() & "/Deficiency type: " & DefType() & Environment.NewLine
    End Function

    'Returns the Deficiency Type
    Private Function DefType() As String
        Select Case _Catagory
            Case 1
                Return "Vitamin"
            Case 2
                Return "Mineral"
            Case 3
                Return "Other"
            Case 4
                Return "Unknown"
            Case Else
                Return "Error"
        End Select
    End Function
End Class
