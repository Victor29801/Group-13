﻿' *****************************************************************
' Team Number: 13
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Hans, S (220097353)
' Team Member 3 Details: Victor, A (220000845)
' Team Member 4 Details: Lutchman, KS (219014915)
' Practical: Team Project
' Class name: Infectious
' *****************************************************************

Option Explicit On
Option Strict On
Option Infer Off

<Serializable()> Public Class Infectious
    Inherits Diseases

    'Attributes
    Private _Tranmission As Integer
    Private _Contagious As Boolean

    'Constructor
    Public Sub New(name As String, NumCountries As Integer, TranType As Integer, Cont As Boolean)
        MyBase.New(name, NumCountries)
        _Type = "Infectious"
        _Tranmission = TranType
        _Contagious = Cont
    End Sub

    'Methods
    Public Overrides Function AverageCasesForDisease() As Double
        Return MyBase.AverageCasesForDisease()
    End Function

    Public Overrides Function TotalDeathToll() As Integer
        Return MyBase.TotalDeathToll()
    End Function

    Public Overrides Function HighestCases() As Integer
        Return MyBase.HighestCases()
    End Function

    Public Overrides Function Display() As String
        Return MyBase.Display() & "/Transmission type: " & TransType() & " /Contagious: " & _Contagious & Environment.NewLine
    End Function

    'Returns the Transmission Type
    Private Function TransType() As String
        Select Case _Tranmission
            Case 1
                Return "Air"
            Case 2
                Return "Water"
            Case 3
                Return "Contact"
            Case 4
                Return "Other"
            Case 5
                Return "Unknown"
            Case Else
                Return "Error"
        End Select
    End Function
End Class
