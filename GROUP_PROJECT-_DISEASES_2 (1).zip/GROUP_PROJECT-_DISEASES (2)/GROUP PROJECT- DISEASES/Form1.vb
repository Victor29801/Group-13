﻿' *****************************************************************
' Team Number: 13
' Team Member 1 Details: Moses, T (220020108)
' Team Member 2 Details: Hans, S (220097353)
' Team Member 3 Details: Victor, A (220000845)
' Team Member 4 Details: Lutchman, KS (219014915)
' Practical: Team Project
' Class name: frmDiseaseInfo
' *****************************************************************
Option Explicit On
Option Infer Off
Option Strict On

Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class frmDiseaseInfo
    'Variables
    Private ObjDiseases() As Diseases
    Private NumDiseases, NumCountries As Integer
    Private objPhysiological As Physiological
    Private objInfectious As Infectious
    Private objhereditary As Hereditary
    Private objDefieciency As Deficiency

    'File Variables
    Private FS As FileStream
    Private BF As BinaryFormatter
    Private Const FileName As String = "Disease Information.txt"

    'Enumeration
    Enum DiseaseType
        Deficiency = 1
        Infectious
        Hereditary
        Physiological
    End Enum

    'Buttons 
    Private Sub btnSet_Click(sender As Object, e As EventArgs) Handles btnSet.Click
        'Sets the number of diseases
        NumDiseases = CInt(InputBox("Enter the number of Diseases:", "Disease Number Entry"))
        ReDim ObjDiseases(NumDiseases)

        'Sets the number of countries
        NumCountries = CInt(InputBox("Enter the number of Countries:", "Country Number Entry"))

        'Set grid dimensions 
        grdDisease.Rows = NumDiseases + 1
        grdDisease.Cols = 5

        'Clears the grid 
        For n As Integer = 1 To NumDiseases
            For x As Integer = 1 To 4
                PT(n, x, " ")
            Next x
        Next n

        'Labels the grid
        LabelGrid()
    End Sub

    Private Sub btnStore_Click(sender As Object, e As EventArgs) Handles btnInput.Click
        'Gets the input from the user 
        For s As Integer = 1 To NumDiseases
            Dim Diseases As Integer = CInt(InputBox("Please select the type of Disease : " &
                                        Environment.NewLine & "1-Deficiency:" &
                                        Environment.NewLine & "2-Infectious :" &
                                        Environment.NewLine & "3-Hereditary :" &
                                        Environment.NewLine & "4-Physiological :", "Disease Type Entry"))

            Dim DiseaseID As String = InputBox("Disease Name:", "Disease Name Entry")
            PT(s, 0, DiseaseID)

            'Gets user input for specific type
            Select Case Diseases
                Case DiseaseType.Deficiency
                    Dim DefType As Integer
                    DefType = CInt(InputBox("Select Deficiency Type : " &
                                        Environment.NewLine & "1-Vitamin :" &
                                        Environment.NewLine & "2-Mineral :" &
                                        Environment.NewLine & "3-Other :" &
                                        Environment.NewLine & "4-Unknown :", "Deficiency Type"))

                    objDefieciency = New Deficiency(DiseaseID, NumCountries, DefType)

                    For m As Integer = 1 To NumCountries
                        objDefieciency.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?", "Cases Entry"))
                        objDefieciency.DeathToll(m) = CInt(InputBox("How many deaths for country " & CStr(m) & "?", "Deaths Entry"))
                    Next m

                    ObjDiseases(s) = objDefieciency

                Case DiseaseType.Infectious
                    Dim Transmission As Integer
                    Transmission = CInt(InputBox("Select Transmission Medium: " &
                                        Environment.NewLine & "1-Air:" &
                                        Environment.NewLine & "2-Water :" &
                                        Environment.NewLine & "3-Contact :" &
                                        Environment.NewLine & "4-Other :" &
                                        Environment.NewLine & "5-Unknown :", "Transmission Medium"))

                    Dim Value As String = InputBox("Is the Disease Contagious? Y - Yes or N - No", "Contagious")
                    Dim Contagious As Boolean
                    If Value = "Y" Then
                        Contagious = True
                    Else
                        Contagious = False
                    End If
                    objInfectious = New Infectious(DiseaseID, NumCountries, Transmission, Contagious)

                    For m As Integer = 1 To NumCountries
                        objInfectious.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?", "Cases Entry"))
                        objInfectious.DeathToll(m) = CInt(InputBox("How many deaths for country " & CStr(m) & "?", "Deaths Entry"))
                    Next m

                    ObjDiseases(s) = objInfectious

                Case DiseaseType.Hereditary
                    Dim Gender As Integer
                    Gender = CInt(InputBox("Select Gender : " &
                                        Environment.NewLine & "1-Male:" &
                                        Environment.NewLine & "2-Female :" &
                                        Environment.NewLine & "3-Other :" &
                                        Environment.NewLine & "4-Unknown :", "Select Gender"))

                    objhereditary = New Hereditary(DiseaseID, NumCountries, Gender)

                    For m As Integer = 1 To NumCountries
                        objhereditary.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?", "Cases Entry"))
                        objhereditary.DeathToll(m) = CInt(InputBox("How many deaths for country " & CStr(m) & "?", "Deaths Entry"))
                    Next m

                    ObjDiseases(s) = objhereditary

                Case DiseaseType.Physiological
                    objPhysiological = New Physiological(DiseaseID, NumCountries)
                    For m As Integer = 1 To NumCountries
                        objPhysiological.Countries(m) = CInt(InputBox("How many cases for country " & CStr(m) & " ?", "Cases Entry"))
                        objPhysiological.DeathToll(m) = CInt(InputBox("How many deaths for country " & CStr(m) & "?", "Deaths Entry"))
                    Next m

                    objPhysiological.BodyPart = InputBox("Which Body Part is majorly affected ?", "Body Part Affected")

                    ObjDiseases(s) = objPhysiological
            End Select
        Next s
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        'output to the grid 
        Dim TotalDeaths, HighestCase As Integer
        Dim AvgCases As Double

        For s As Integer = 1 To NumDiseases
            PT(s, 1, ObjDiseases(s).Type)

            'Deficiency: 
            Dim tempObjDefieciency As Deficiency
            tempObjDefieciency = TryCast(ObjDiseases(s), Deficiency)
            If Not (tempObjDefieciency Is Nothing) Then
                HighestCase = tempObjDefieciency.HighestCases()
                AvgCases = tempObjDefieciency.AverageCasesForDisease()
                TotalDeaths = tempObjDefieciency.TotalDeathToll()
            End If

            'Infectious
            Dim tempObjInfectious As Infectious
            tempObjInfectious = TryCast(ObjDiseases(s), Infectious)
            If Not (tempObjInfectious Is Nothing) Then
                HighestCase = tempObjInfectious.HighestCases()
                AvgCases = tempObjInfectious.AverageCasesForDisease()
                TotalDeaths = tempObjInfectious.TotalDeathToll()
            End If

            'Hereditary
            Dim tempObjhereditary As Hereditary
            tempObjhereditary = TryCast(ObjDiseases(s), Hereditary)
            If Not (tempObjhereditary Is Nothing) Then
                HighestCase = tempObjhereditary.HighestCases()
                AvgCases = tempObjhereditary.AverageCasesForDisease()
                TotalDeaths = tempObjhereditary.TotalDeathToll()
            End If

            'Physiological
            Dim tempObjPhysiological As Physiological
            tempObjPhysiological = TryCast(ObjDiseases(s), Physiological)
            If Not (tempObjPhysiological Is Nothing) Then
                HighestCase = tempObjPhysiological.HighestCases()
                AvgCases = tempObjPhysiological.AverageCasesForDisease()
                TotalDeaths = tempObjPhysiological.TotalDeathToll()
            End If

            PT(s, 2, Format(AvgCases, "0.00"))
            PT(s, 3, CStr(TotalDeaths))
            PT(s, 4, "Country:" & HighestCase)
        Next
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        'Create the file 
        FS = New FileStream(FileName, FileMode.Create, FileAccess.ReadWrite)
        MsgBox("File Created!",, "File Created Message")
        FS.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Write to file
        FS = New FileStream(FileName, FileMode.Open, FileAccess.Write)
        BF = New BinaryFormatter()
        For s As Integer = 1 To NumDiseases
            BF.Serialize(FS, ObjDiseases(s))
        Next
        FS.Close()
        MsgBox("File Saved!",, "File Saved Message")
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnRead.Click
        'Displaying Data
        txtDisplay.Clear()

        'Setting filestreams
        FS = New FileStream(FileName, FileMode.Open, FileAccess.Read)
        BF = New BinaryFormatter()

        'Deserialising data
        While FS.Position < FS.Length
            Dim tempDisease As Object
            tempDisease = BF.Deserialize(FS)

            If TypeOf tempDisease Is Infectious Then
                Dim temp As Infectious
                temp = DirectCast(tempDisease, Infectious)
                txtDisplay.Text &= temp.Display
            End If
            If TypeOf tempDisease Is Hereditary Then
                Dim temp As Hereditary
                temp = DirectCast(tempDisease, Hereditary)
                txtDisplay.Text &= temp.Display
            End If

            If TypeOf tempDisease Is Deficiency Then
                Dim temp As Deficiency
                temp = DirectCast(tempDisease, Deficiency)
                txtDisplay.Text &= temp.Display
            End If

            If TypeOf tempDisease Is Physiological Then
                Dim temp As Physiological
                temp = DirectCast(tempDisease, Physiological)
                txtDisplay.Text &= temp.Display
            End If
        End While
        FS.Close()
    End Sub

    'Helper Methods
    Private Sub PT(r As Integer, c As Integer, t As String)
        'Places Text in the grid 
        grdDisease.Row = r
        grdDisease.Col = c
        grdDisease.Text = t
    End Sub

    Private Sub LabelGrid()
        'Labels the Grid 
        For a As Integer = 1 To NumDiseases
            PT(a, 0, "Disease: " & CStr(a))
        Next

        PT(0, 0, "Disease Name")
        PT(0, 1, "Type")
        PT(0, 2, "Average Cases")
        PT(0, 3, "Total Deaths")
        PT(0, 4, "Country Most Deaths")
    End Sub

End Class
