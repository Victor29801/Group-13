﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDiseaseInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlAll = New System.Windows.Forms.Panel()
        Me.pnlFiles = New System.Windows.Forms.Panel()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnRead = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.grdDisease = New UJGrid.UJGrid()
        Me.pnlStore = New System.Windows.Forms.Panel()
        Me.btnSet = New System.Windows.Forms.Button()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnInput = New System.Windows.Forms.Button()
        Me.pnlAll.SuspendLayout()
        Me.pnlFiles.SuspendLayout()
        Me.pnlStore.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlAll
        '
        Me.pnlAll.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.pnlAll.Controls.Add(Me.pnlFiles)
        Me.pnlAll.Controls.Add(Me.txtDisplay)
        Me.pnlAll.Controls.Add(Me.grdDisease)
        Me.pnlAll.Controls.Add(Me.pnlStore)
        Me.pnlAll.Location = New System.Drawing.Point(0, 0)
        Me.pnlAll.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlAll.Name = "pnlAll"
        Me.pnlAll.Size = New System.Drawing.Size(1074, 613)
        Me.pnlAll.TabIndex = 0
        '
        'pnlFiles
        '
        Me.pnlFiles.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.pnlFiles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlFiles.Controls.Add(Me.btnCreate)
        Me.pnlFiles.Controls.Add(Me.btnRead)
        Me.pnlFiles.Controls.Add(Me.btnSave)
        Me.pnlFiles.Location = New System.Drawing.Point(16, 302)
        Me.pnlFiles.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlFiles.Name = "pnlFiles"
        Me.pnlFiles.Size = New System.Drawing.Size(345, 248)
        Me.pnlFiles.TabIndex = 7
        '
        'btnCreate
        '
        Me.btnCreate.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCreate.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnCreate.Location = New System.Drawing.Point(51, 25)
        Me.btnCreate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(231, 47)
        Me.btnCreate.TabIndex = 4
        Me.btnCreate.Text = "Create File"
        Me.btnCreate.UseVisualStyleBackColor = False
        '
        'btnRead
        '
        Me.btnRead.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnRead.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRead.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnRead.Location = New System.Drawing.Point(51, 172)
        Me.btnRead.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnRead.Name = "btnRead"
        Me.btnRead.Size = New System.Drawing.Size(231, 46)
        Me.btnRead.TabIndex = 6
        Me.btnRead.Text = "Read from File"
        Me.btnRead.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSave.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSave.Location = New System.Drawing.Point(51, 100)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(231, 46)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "Write to File"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'txtDisplay
        '
        Me.txtDisplay.Location = New System.Drawing.Point(373, 302)
        Me.txtDisplay.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(677, 248)
        Me.txtDisplay.TabIndex = 2
        '
        'grdDisease
        '
        Me.grdDisease.FixedCols = 1
        Me.grdDisease.FixedRows = 1
        Me.grdDisease.Location = New System.Drawing.Point(373, 15)
        Me.grdDisease.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.grdDisease.Name = "grdDisease"
        Me.grdDisease.Scrollbars = System.Windows.Forms.ScrollBars.Both
        Me.grdDisease.Size = New System.Drawing.Size(677, 252)
        Me.grdDisease.TabIndex = 1
        '
        'pnlStore
        '
        Me.pnlStore.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.pnlStore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlStore.Controls.Add(Me.btnSet)
        Me.pnlStore.Controls.Add(Me.btnDisplay)
        Me.pnlStore.Controls.Add(Me.btnInput)
        Me.pnlStore.Location = New System.Drawing.Point(16, 15)
        Me.pnlStore.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlStore.Name = "pnlStore"
        Me.pnlStore.Size = New System.Drawing.Size(344, 252)
        Me.pnlStore.TabIndex = 0
        '
        'btnSet
        '
        Me.btnSet.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnSet.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSet.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnSet.Location = New System.Drawing.Point(49, 15)
        Me.btnSet.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnSet.Name = "btnSet"
        Me.btnSet.Size = New System.Drawing.Size(231, 48)
        Me.btnSet.TabIndex = 1
        Me.btnSet.Text = "Set"
        Me.btnSet.UseVisualStyleBackColor = False
        '
        'btnDisplay
        '
        Me.btnDisplay.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnDisplay.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDisplay.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnDisplay.Location = New System.Drawing.Point(49, 169)
        Me.btnDisplay.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(231, 46)
        Me.btnDisplay.TabIndex = 3
        Me.btnDisplay.Text = "Display"
        Me.btnDisplay.UseVisualStyleBackColor = False
        '
        'btnInput
        '
        Me.btnInput.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnInput.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnInput.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInput.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnInput.Location = New System.Drawing.Point(49, 94)
        Me.btnInput.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnInput.Name = "btnInput"
        Me.btnInput.Size = New System.Drawing.Size(231, 48)
        Me.btnInput.TabIndex = 2
        Me.btnInput.Text = "Input Information"
        Me.btnInput.UseVisualStyleBackColor = False
        '
        'frmDiseaseInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1077, 572)
        Me.Controls.Add(Me.pnlAll)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmDiseaseInfo"
        Me.Text = "Disease Information Collection"
        Me.pnlAll.ResumeLayout(False)
        Me.pnlAll.PerformLayout()
        Me.pnlFiles.ResumeLayout(False)
        Me.pnlStore.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlAll As Panel
    Friend WithEvents pnlStore As Panel
    Friend WithEvents btnDisplay As Button
    Friend WithEvents btnInput As Button
    Friend WithEvents btnSet As Button
    Friend WithEvents grdDisease As UJGrid.UJGrid
    Friend WithEvents btnCreate As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents btnRead As Button
    Friend WithEvents pnlFiles As Panel
End Class
