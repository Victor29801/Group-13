﻿Public Class frmDiseaseControl

End Class
